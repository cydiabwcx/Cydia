<?php
if (!defined("DCRM")) {
	exit;
}
define("AUTOFILL_PRE", "");
define("AUTOFILL_NONAME", "[未命名]");
define("AUTOFILL_MASTER", "");
define("AUTOFILL_FULLNAME", "");
define("AUTOFILL_EMAIL", "i.82@me.com");
define("AUTOFILL_SITE", "");
define("AUTOFILL_DESCRIPTION", "一个萌萌哒软件包。");
define("AUTOFILL_SEO", "新软件源");
define("AUTOFILL_KEYWORDS", "");
define("AUTOFILL_PAYPAL", "");
define("AUTOFILL_STATISTICS", "");
define("AUTOFILL_STATISTICS_INFO", "");
define("AUTOFILL_ADVERTISEMENT", "");
define("AUTOFILL_DUOSHUO_KEY", "");
?>
