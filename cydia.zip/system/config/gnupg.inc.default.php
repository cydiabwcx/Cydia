<?php
if (!defined("DCRM")) {
	exit;
}
//该文件用于软件源签名，如果不知道该文件用途，请勿修改该文件。
define("DCRM_GNUPG_ENABLED",0);
define("DCRM_GNUPG_PASS","");
define("DCRM_GNUPG_NAME","");
define("DCRM_GNUPG_PATH","");
?>
